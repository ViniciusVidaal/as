(function () {
  const preloader = document.querySelector(".preloader");
  const menuToggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav");
  const slides = Array.from(document.querySelectorAll(".hero__slide"));
  const heroDots = Array.from(document.querySelectorAll(".hero__dots button"));
  const testimonials = Array.from(document.querySelectorAll(".testimonial"));
  const testimonialDots = Array.from(document.querySelectorAll(".testimonial-dots button"));
  const imageCarousels = Array.from(document.querySelectorAll(".image-carousel"));
  let currentSlide = 0;
  let currentTestimonial = 0;
  let ticking = false;

  if (window.lucide) {
    window.lucide.createIcons();
  }

  function hidePreloader() {
    if (!preloader) return;
    preloader.classList.add("is-hidden");
    setTimeout(() => preloader.remove(), 650);
  }

  window.addEventListener("load", () => {
    setTimeout(hidePreloader, 700);
  });
  setTimeout(hidePreloader, 2200);

  if (menuToggle && nav) {
    menuToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("is-open");
      menuToggle.setAttribute("aria-expanded", String(isOpen));
    });

    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        nav.classList.remove("is-open");
        menuToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  function updateHeaderState() {
    const header = document.querySelector(".site-header");
    if (!header) return;
    header.classList.toggle("is-scrolled", window.scrollY > 80);
    ticking = false;
  }

  window.addEventListener(
    "scroll",
    () => {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(updateHeaderState);
    },
    { passive: true }
  );
  updateHeaderState();

  function setHeroSlide(index) {
    if (!slides.length) return;
    currentSlide = index;
    slides.forEach((slide, slideIndex) => {
      slide.classList.toggle("is-active", slideIndex === index);
    });
    heroDots.forEach((dot, dotIndex) => {
      dot.classList.toggle("is-active", dotIndex === index);
    });
  }

  heroDots.forEach((dot, index) => {
    dot.addEventListener("click", () => setHeroSlide(index));
  });

  if (slides.length > 1) {
    setInterval(() => {
      setHeroSlide((currentSlide + 1) % slides.length);
    }, 5200);
  }

  function setTestimonial(index) {
    if (!testimonials.length) return;
    currentTestimonial = index;
    testimonials.forEach((testimonial, testimonialIndex) => {
      testimonial.classList.toggle("is-active", testimonialIndex === index);
    });
    testimonialDots.forEach((dot, dotIndex) => {
      dot.classList.toggle("is-active", dotIndex === index);
    });
  }

  testimonialDots.forEach((dot, index) => {
    dot.addEventListener("click", () => setTestimonial(index));
  });

  if (testimonials.length > 1) {
    setInterval(() => {
      setTestimonial((currentTestimonial + 1) % testimonials.length);
    }, 6500);
  }

  imageCarousels.forEach((carousel) => {
    const carouselSlides = Array.from(carousel.querySelectorAll(".image-carousel__slide"));
    const carouselDots = Array.from(carousel.querySelectorAll(".carousel-dots button"));
    let activeIndex = 0;

    function setImageSlide(index) {
      activeIndex = index;
      carouselSlides.forEach((slide, slideIndex) => {
        slide.classList.toggle("is-active", slideIndex === index);
      });
      carouselDots.forEach((dot, dotIndex) => {
        dot.classList.toggle("is-active", dotIndex === index);
      });
    }

    carouselDots.forEach((dot, index) => {
      dot.addEventListener("click", () => setImageSlide(index));
    });

    if (carouselSlides.length > 1) {
      setInterval(() => {
        setImageSlide((activeIndex + 1) % carouselSlides.length);
      }, 4700);
    }
  });

  function setupGsapAnimations() {
    if (!window.gsap) return;

    const { gsap } = window;
    const ScrollTrigger = window.ScrollTrigger;

    if (ScrollTrigger) {
      gsap.registerPlugin(ScrollTrigger);
    }

    gsap.defaults({
      ease: "power3.out",
      duration: 0.9
    });

    const progress = document.createElement("div");
    progress.className = "scroll-progress";
    document.body.appendChild(progress);

    gsap.from(".site-header", {
      y: -24,
      opacity: 0,
      duration: 0.7,
      delay: 0.2
    });

    gsap.from(".hero .eyebrow, .hero h1, .hero p, .hero__actions", {
      y: 34,
      opacity: 0,
      stagger: 0.12,
      delay: 0.35
    });

    if (!ScrollTrigger) return;

    gsap.to(progress, {
      scaleX: 1,
      ease: "none",
      scrollTrigger: {
        trigger: document.documentElement,
        start: "top top",
        end: "bottom bottom",
        scrub: 0.25
      }
    });

    gsap.utils.toArray("section").forEach((section) => {
      const head = section.querySelector(".section-head");
      if (!head) return;

      gsap.from(head.children, {
        y: 34,
        opacity: 0,
        stagger: 0.1,
        scrollTrigger: {
          trigger: section,
          start: "top 72%",
          once: true
        }
      });
    });

    [
      ".metrics article",
      ".service-card",
      ".check-grid span",
      ".image-carousel",
      ".method-grid article",
      ".faq details"
    ].forEach((selector) => {
      gsap.utils.toArray(selector).forEach((element, index) => {
        gsap.from(element, {
          y: 42,
          opacity: 0,
          scale: 0.98,
          transformOrigin: "center bottom",
          duration: 0.65,
          delay: (index % 4) * 0.06,
          scrollTrigger: {
            trigger: element,
            start: "top 82%",
            once: true
          }
        });
      });
    });

    gsap.utils.toArray(".split, .booking__box, .contact__grid").forEach((row) => {
      gsap.from(row.children, {
        x: (index) => (index === 0 ? -34 : 34),
        opacity: 0,
        stagger: 0.16,
        scrollTrigger: {
          trigger: row,
          start: "top 76%",
          once: true
        }
      });
    });

    gsap.utils.toArray(".btn, .header-cta, .fab").forEach((button) => {
      button.addEventListener("mouseenter", () => {
        gsap.to(button, { scale: 1.06, duration: 0.22, ease: "power2.out" });
      });

      button.addEventListener("mouseleave", () => {
        gsap.to(button, { scale: 1, duration: 0.22, ease: "power2.out" });
      });
    });

    gsap.from(".fab", {
      scale: 0.5,
      opacity: 0,
      stagger: 0.1,
      delay: 0.8
    });

    ScrollTrigger.refresh();

    window.addEventListener("load", () => {
      ScrollTrigger.refresh();
    });
  }

  setupGsapAnimations();
})();
